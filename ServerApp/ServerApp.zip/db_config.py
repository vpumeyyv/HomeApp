#config file containing credentials for rds mysql instance
db_username = "vpumeyyv"
db_password = "A1on1onMotek2016"
db_name = "homeapp" 
db_host="xxxxxxxxxxxxxx"
db_port = 3306
